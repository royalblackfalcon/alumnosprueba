<html>
    <head>
        <meta charset="utf-8"/>
        <base<meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <title>CRUD ALUMNOS</title>
        <link rel="stylesheet" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" href="css/jquery-ui.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/dataTables.bootstrap4.min.css" rel="stylesheet">
    </head>
    <body>







