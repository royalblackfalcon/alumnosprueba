<?php
class conexion 
    {
        private static $conexion = null;
        public static function conectar()
        {
            try
            {
                self::$conexion=mysqli_connect('localhost', 'root','','escuelaprueba');
                
            } catch (PDOException $ex) {
                echo 'error de: '.$ex->getMessage();
                die();

            }
            return self::$conexion;
            

        }
    }

