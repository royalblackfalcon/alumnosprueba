<?php
include 'conexion.php';
 $accion = new crudex();
 
 if (isset($_GET['funcion'])) 
    {
      $funcionin = $_GET['funcion'];
      
      if($funcionin == 1)
        {
          $nombre = $_GET['nombre'];
          $apellido = $_GET['apellido'];
          $fechanacimiento = $_GET['fechanacimiento'];
          $generonombre = $_GET['generonombre'];
          $grado = $_GET['grado'];
          $matricula = $_GET['matricula'];
          $fechacambio =  explode("/", $fechanacimiento);
          $fechacambio1 = $fechacambio[2]."/".$fechacambio[0]."/".$fechacambio[1];
          
          $accion->setAgregar($nombre,$apellido,$fechacambio1,$generonombre,$grado,$matricula);
        }
       if($funcionin == 2)
        {
          $nombre = $_GET['nombre'];
          $apellido = $_GET['apellido'];
          $fechanacimiento = $_GET['fechanacimiento'];
          $generonombre = $_GET['generonombre'];
          $grado = $_GET['grado'];
          $matricula = $_GET['matricula'];
          $id = $_GET['id'];
          $fechacambio =  explode("/", $fechanacimiento);
          $fechacambio1 = $fechacambio[2]."/".$fechacambio[0]."/".$fechacambio[1];
          
          $accion->setActualizar($nombre,$apellido,$fechacambio1,$generonombre,$grado,$matricula,$id);
        }
        
       if($funcionin == 3)
        {
           $matricula = $_GET['matricula'];
           $activo = $_GET['activo'];
           $fechainicio = $_GET['fachainicio'];
           $fechafin = $_GET['fechafin'];
           $fechaalta = $_GET['fechaalta'];
           $fechabaja = $_GET['fechabaja'];
           
           if($fechainicio != '')
                {
                    $fechainicio1 =  explode("/", $fechainicio);
                    $fechainicio2 = $fechainicio1[2]."/".$fechainicio1[0]."/".$fechainicio1[1];
                }
           else
                {
                    $fechainicio2 = "";
                }
           if($fechafin != '')
                {
                    $fechafin1 =  explode("/", $fechafin);
                    $fechafin2 = $fechafin1[2]."/".$fechafin1[0]."/".$fechafin1[1];
                }
           else
                {
                    $fechafin2 = "";
                }
           $data = $accion->setBusquedas($matricula,$activo,$fechainicio2,$fechafin2,$fechaalta,$fechabaja);
           
           echo json_encode($data);
        }
    }
class crudex
    {
        private $conexionNu;
        private $datosGenerales;
        
        public function __construct()
            {
                $this->conexionNu = conexion::conectar();
                $this->datosGenerales = array();
                
            }
            
        public function getDatosGenerales()
            {
                $resultado = $this->conexionNu->query('call consultatodo');
                while($datos=$resultado->fetch_assoc())
                    {
                        $this->datosGenerales[]=$datos;
                    }
                 return $this->datosGenerales;
            }
            
        public function setAgregar($nombre,$apellido,$fechanacimiento,$genero,$gradoescolar,$matricula)
            {
                $resultset = $this->conexionNu->query("call agregarAlumno('$nombre','$apellido','$fechanacimiento','$genero','$gradoescolar','$matricula',now())");
                
                
            }
            
        public function getCargar($id)
            {
                $resultset= $this->conexionNu->query("call consultaid($id)");
                while ($datos=$resultset->fetch_assoc())
                    {
                        $this->datosGenerales[]=$datos;
                    }
                return $this->datosGenerales;
            }
            
        public function setActualizar($nombre,$apellido,$fechacambio1,$generonombre,$grado,$matricula,$id)
            {
                $resultset = $this->conexionNu->query("call actualizardatos('$nombre','$apellido','$fechacambio1','$grado','$matricula','$id')");
                
            }
            
        public function getEliminar($id)
            {
                $resultset= $this->conexionNu->query("call eliminardato($id)");

            }
            
        public function getBajaalta($id,$activo)
            {
                $resultset= $this->conexionNu->query("call BajaAltalogica($id,$activo)");

            }
       public function setBusquedas($matricula,$activo,$fechainicio2,$fechafin2,$fechaalta,$fechabaja)
            {
            
                $resultado = $this->conexionNu->query("call busquedaalumnos('$matricula','$activo','$fechainicio2','$fechafin2','$fechaalta','$fechabaja')");
                while($datos=$resultado->fetch_assoc())
                    {
                        $this->datosGenerales[]=$datos;
                    }
                 return $this->datosGenerales;
            }
    }


































































