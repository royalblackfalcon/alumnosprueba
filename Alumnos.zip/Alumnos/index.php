<?php
include 'header.php';
require_once 'controlador/crudp2.php';
$controlador =  new crudp2();
if(!isset($_GET['crud']))
    {
        $controlador->principal();
    }
 else 
    {
                if($_GET['crud'] == "nuevo")
                    {
                        $controlador ->agregar(); 
                    }
                if($_GET['crud'] == "actualizar")
                    {
                        $id=$_GET['id'];
                        $controlador ->actualizar($id);
                    }
                if($_GET['crud'] == "eliminar")
                    {
                        $id=$_GET['id'];
                        $controlador ->eliminar($id);
                    } 
                 if($_GET['crud'] == "bajaalta")
                    {
                        $id=$_GET['id'];
                        $activo = $_GET['activo'];
                        $controlador ->bajaalta($id,$activo);
                    }
    }
include 'footer.php';
?>
