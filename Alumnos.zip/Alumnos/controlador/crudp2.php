<?php
require_once 'modelo/crudex.php';
class crudp2
    {
        public function principal() 
            {
                $datosgenerales2 = new crudex();
                $datosM = $datosgenerales2->getDatosGenerales();
                require_once 'vistas/bodyindex.php';
            }
        public function agregar()
            {
                require_once ('vistas/agregar.php');
            }
            
       public function actualizar($id)
            {
                $datosGenerales2 = new crudex();
                $datosM = $datosGenerales2->getCargar($id);
                require_once ('vistas/actualizar.php');
            }
            
       public function bajaalta($id,$activo)
            {
                $datosGenerales2 = new crudex();
                $datosM = $datosGenerales2->getBajaalta($id,$activo);
                header('Location: index.php');
            }
        
       public function eliminar($id)
            {
                $datosGenerales2 = new crudex();
                $datosM = $datosGenerales2->getEliminar($id);
                header('Location: index.php');
            }
    }
















