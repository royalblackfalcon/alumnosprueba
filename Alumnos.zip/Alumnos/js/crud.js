$(document).ready(function() 
                {
                   $('#example').DataTable(); 
                   $( "#fechainicio" ).datepicker();
                   $( "#fechafinal" ).datepicker();
                   $( "#fechanacimiento").datepicker();
                   
                   $("#agregar").click(function() 
                            {
                                var nombre = $("#nombre").val(); 
                                var apellido = $("#apellido").val();
                                var fechanacimiento = $("#fechanacimiento").val();
                                var genero = $('#genero option:selected').attr("value");
                                var grado = $("#grado").val();
                                var matricula = $("#matricula").val();
                                var agregar = 0;
                                var errores = "";
                                var generonombre = "";
                                
                                if(nombre.length < 4)
                                    {
                                        agregar = 1;
                                        errores = errores +"El nombre no puede estar vacío \n";
                                    }
                                if(apellido.length < 4)
                                    {
                                        agregar = 1;
                                        errores = errores +"El apellido no puede estar vacío \n";
                                    }
                                if(genero == 0)
                                   {
                                       agregar = 1;
                                       errores = errores +"Debe seleccionar un genero \n";
                                   } 
                                if(matricula.length < 4)
                                    {
                                        agregar = 1;
                                        errores = errores +"La matricula no puede estar vacío \n";
                                    }
                                if(grado.length < 4)
                                    {
                                        agregar = 1;
                                        errores = errores +"El grado no puede estar vacío \n";
                                    }
                                if(genero == 1)
                                    {
                                        generonombre = "Masculino";
                                    }
                                if(genero == 2)
                                    {
                                        generonombre = "Femenino";
                                    }
                                
                                if(agregar == 0)
                                    {
                                        $.ajax({

                                            url:'modelo/crudex.php',
                                            type: 'GET',
                                            data: {
                                                    nombre: nombre,
                                                    apellido: apellido,
                                                    fechanacimiento: fechanacimiento,
                                                    generonombre: generonombre,
                                                    grado: grado,
                                                    matricula:matricula,
                                                    funcion:1,
                                                  },
                                            dataType: 'JSON',
                                            async: false,
                                            success: function(response){

                                                   window.location.href = 'index.php';
                                                   
                                                }
                                            });
                                    }
                                else
                                    {
                                        alert(errores);
                                    }
                                
                            });
                            
                    $("#actualizar").click(function() 
                            {
                                var nombre = $("#nombre").val(); 
                                var apellido = $("#apellido").val();
                                var fechanacimiento = $("#fechanacimiento").val();
                                var genero = $('#genero option:selected').attr("value");
                                var grado = $("#grado").val();
                                var matricula = $("#matricula").val();
                                var agregar = 0;
                                var errores = "";
                                var generonombre = "";
                                var id = $("#id").val();
                                
                                if(nombre.length < 4)
                                    {
                                        agregar = 1;
                                        errores = errores +"El nombre no puede estar vacío \n";
                                    }
                                if(apellido.length < 4)
                                    {
                                        agregar = 1;
                                        errores = errores +"El apellido no puede estar vacío \n";
                                    }
                                if(genero == 0)
                                   {
                                       agregar = 1;
                                       errores = errores +"Debe seleccionar un genero \n";
                                   } 
                                if(matricula.length < 4)
                                    {
                                        agregar = 1;
                                        errores = errores +"La matricula no puede estar vacío \n";
                                    }
                                if(grado.length < 4)
                                    {
                                        agregar = 1;
                                        errores = errores +"El grado no puede estar vacío \n";
                                    }
                                if(genero == 1)
                                    {
                                        generonombre = "Masculino";
                                    }
                                if(genero == 2)
                                    {
                                        generonombre = "Femenino";
                                    }
                                
                                if(agregar == 0)
                                    {
                                        $.ajax({

                                            url:'modelo/crudex.php',
                                            type: 'GET',
                                            data: {
                                                    nombre: nombre,
                                                    apellido: apellido,
                                                    fechanacimiento: fechanacimiento,
                                                    generonombre: generonombre,
                                                    grado: grado,
                                                    matricula:matricula,
                                                    funcion:2,
                                                    id:id,
                                                  },
                                            dataType: 'JSON',
                                            async: false,
                                            success: function(response){

                                                   window.location.href = 'index.php';
                                                   
                                                }
                                            });
                                    }
                                else
                                    {
                                        alert(errores);
                                    }
                                
                            });
                            
                        $("#buscar").click(function() 
                            {
                                var matricula = $("#matricula").val();
                                var activo = $('#bajaalta option:selected').attr("value");
                                var fechainicio = $("#fechainicio").val();
                                var fechafin = $("#fechafinal").val();
                                var fechaalta = 0;
                                var fechabaja = 0;
                               
                                if(activo == 1)
                                    {
                                        fechaalta = 1;
                                    }
                                if(activo == 2)
                                    {
                                        fechabaja = 1;
                                    }
                                  
                                        $.ajax({

                                            url:'modelo/crudex.php',
                                            type: 'GET',
                                            data: {
                                                    matricula: matricula,
                                                    activo: activo,
                                                    fachainicio: fechainicio,
                                                    fechafin: fechafin,
                                                    fechaalta: fechaalta,
                                                    fechabaja: fechabaja,
                                                    funcion:3,
                                                  },
                                            dataType: 'JSON',
                                            async: false,
                                            success: function(response){

                                                    $('#example tbody').html('');
                                                    var html = "";
                                                    var data = response;
                                                    var coneteo = data.length;
                                                    for(var i = 0; i<coneteo; i++)
                                                        {
                                                            var element = data[i];
                                                            var activo1 = element['activo'];
                                                            var activo2 = "";
                                                            if(activo1 == 1)
                                                                {
                                                                    activo2 = "Alta";
                                                                }
                                                            if(activo1 == 2)
                                                                {
                                                                    activo2 = "Baja";
                                                                }    
                                                            html = html+ '<tr><td>'+element['nombre']+" "+element['apellido']+'</td><td>'+element['fechaNacimiento']+'</td><td>'+element['genero']+'</td><td>'+element['gradoescolar']+'</td><td>'+element['matricula']+'</td><td>'+activo2+'</td><td><a class="btn btn-success" href="?crud=actualizar&id='+element['id']+'">Actualizar</a><a class="btn btn-info" href="?crud=bajaalta&id='+element['id']+'&activo='+element['activo']+'">'+activo2+'</a><a class="btn btn-danger" href="?crud=eliminar&id='+element['id']+'">Eliminar</a></td><td></td></tr>';
                                                        }
                                                        $('#example').append(html);
                                                }
                                            });
                                   
                            });
                });
