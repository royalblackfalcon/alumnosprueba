<section style="padding: 10px; margin: 10px;">
    <div class="container">
        <div class="row text-center">
            <div class="col-12 col-lg-2" style="padding: 2px 2px 2px 2px"><input type="text" id="matricula"; placeholder="matricula"></div>
            <div class="col-12 col-lg-2">
                <select id="bajaalta">
                    <option value="0">Seleccionar</option>
                    <option value="1">Activo</option>
                    <option value="2">Baja</option>
                </select>
            </div>
            <div class="col-12 col-lg-2" style="padding: 2px 2px 2px 2px"><input type="text" id="fechainicio" placeholder="Fecha inicial"></div>
            <div class="col-12 col-lg-2" style="padding: 2px 2px 2px 2px"><input type="text" id="fechafinal" placeholder="Fecha final"></div>
            <div class="col-12 col-lg-2"><button class="btn btn-success" id="buscar">Buscar</button></div>
        </div>
    </div>
</section>
<section style="padding: 10px; margin: 10px;">
    <div class="container">
        <div class="row">
            <table id="example" class="table table-striped table-bordered">
                <thead>
                    <tr style="text-align: center;">
                        <td>Alumno</td>
                        <td>Fecha nacimiento</td>
                        <td>Genero</td>
                        <td>Grado Escolar</td>
                        <td>Matricula</td>
                        <td>Estatus</td>
                        <td>Acciones</td>
                        <td><a class="btn btn-success" href="?crud=nuevo">Nuevo</a></td>
                    </tr>
                </thead>
                <tbody>
                   <?php
                   foreach ($datosM as $dato)
                    {
                       ?>
                        <tr style="text-align: center;">
                            <td><?php echo $dato["nombre"]." ".$dato["apellido"];?></td>
                            <td><?php echo $dato["fechaNacimiento"];?></td>
                            <td><?php echo $dato["genero"];?></td>
                            <td><?php echo $dato["gradoescolar"];?></td>
                            <td><?php echo $dato["matricula"];?></td>
                            <?php
                                $textobajaalta = "";
                                $activo2 = 0;
                                if($dato['activo'] == 1)
                                    {
                                        $textobajaalta = "Dar de Baja";
                                        $activo2 = 2;
                             ?>
                                <td>Activo</td>
                            <?php
                                    }
                                else
                                    {
                             ?>
                                <td>Baja</td>
                            <?php
                                         $textobajaalta = "Dar de Alta";
                                         $activo = 1;
                                    }
                            ?>
                                <td>
                                    <a class="btn btn-success" href="?crud=actualizar&id=<?php echo $dato['id'];?>">Actualizar</a>
                                    <a class="btn btn-info" href="?crud=bajaalta&id=<?php echo $dato['id'];?>&activo=<?php echo $activo2 ;?>"><?php echo $textobajaalta; ?></a>
                                    <a class="btn btn-danger" href="?crud=eliminar&id=<?php echo $dato['id'];?>">Eliminar</a></td>
                                <td></td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php
          
