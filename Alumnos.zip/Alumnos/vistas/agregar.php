<?php

?>
<section>
    <div class="container">
        <div class="row">
            
                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Nombre:</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><input type="text" id="nombre" name="nombre"/></div>

                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Apellido:</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><input type="text" id="apellido"/></div>

                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Fecha de nacimiento:</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><input type="text" id="fechanacimiento"/></div>

                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Genero:</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom ">
                    <select id="genero">
                        <option value="0">Seleccionar</option>
                        <option value="1">Masculino</option>
                        <option value="2">Femenino</option>
                    </select>
                </div>

                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Grado Escolar</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><input type="text" id="grado"/></div>

                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Matricula:</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><input type="text" id="matricula"/></div>


                <div class="col-12  col-lg-6 md-margin-15px-bottom "><button class="btn btn-success" id="agregar" name="agregar">Agregar</button></div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><a class="btn btn-success" id="regresar" name="regresar" href="index.php">Regresar</a></div>
            
        </div>
    </div>
</section>

<?php

?>















