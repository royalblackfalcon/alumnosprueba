<?php
$nombre = "";
$apellido = "";
$fechanacimiento = "";
$generonombre = "";
$grado = "";
$matricula = "";
 foreach ($datosM as $dato)
    {
        $nombre = $dato['nombre'];
        $apellido = $dato['apellido'];
        $fechanacimiento = $dato['fechaNacimiento'];
        $generonombre = $dato['genero'];
        $grado = $dato['gradoescolar'];
        $matricula = $dato['matricula'];
        $id = $dato['id'];
    }
?>
<section>
    <div class="container">
        <div class="row">
                
                <input type="hidden" id="id" name="id" value="<?php echo $id; ?>"/>
                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Nombre:</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><input type="text" id="nombre" name="nombre" value="<?php echo $nombre; ?>"/></div>

                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Apellido:</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><input type="text" id="apellido" value="<?php echo $apellido; ?>"/></div>

                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Fecha de nacimiento:</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><input type="text" id="fechanacimiento" value="<?php echo $fechanacimiento; ?>"/></div>

                
                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Grado Escolar</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><input type="text" id="grado" value="<?php echo $grado; ?>"/></div>

                <div class="col-12 col-lg-6 md-margin-15px-bottom ">Matricula:</div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><input type="text" id="matricula" value="<?php echo $matricula; ?>"/></div>


                <div class="col-12  col-lg-6 md-margin-15px-bottom "><button class="btn btn-success" id="actualizar" name="actuaizar">Actualizar</button></div>
                <div class="col-12 col-lg-6 md-margin-15px-bottom "><a class="btn btn-success" id="regresar" name="regresar" href="index.php">Regresar</a></div>
            
        </div>
    </div>
</section>

<?php

?>
